<?php
include "config.php";
//This takes all of the checked boxes and puts them into an array
$consent=$_POST['consent'];
if (isset($_POST['priorexp']) && is_array($_POST['priorexp'])){
	foreach($_POST['priorexp'] as $priorexp){
	}
	//this changes the array into a comma separated list for the DB
	$priorexplist = implode(', ',$_POST['priorexp']);
}
$otherservices = $_POST['otherservices'];
$goodcomponents = $_POST['goodcomponents'];
$familiarity = $_POST['familiarity'];
$leveloffamiliarity=$_POST['leveloffamiliarity'];
$necessity = $_POST['necessity'];

$sql = mysqli_query($connection, "INSERT INTO `presurvey`(`ID`, `consent`, `priorexperience`, `otherservices`, `goodcomponents`, `familiarity`, `leveloffamiliarity`, `necessity`) VALUES (NULL,'$consent','$priorexplist', '$otherservices','$goodcomponents','$familiarity','$leveloffamiliarity','$necessity')");
	if($sql){
		header("Location: presurvey.php?success=True");
	}
	

?>