<?php
require_once "config.php";
session_start();
if (isset($_SESSION['username'])){
  $sessusername = $_SESSION['username'];
$compltquery = "SELECT * FROM `questions` WHERE `username` = '$sessusername'";
$results = mysqli_query($connection,$compltquery);
$row = mysqli_fetch_assoc($results);
$points = "SELECT `points` FROM `users` WHERE `username` = '$sessusername'";
$getpoints=mysqli_query($connection, $points);
$row2 = mysqli_fetch_assoc($getpoints);}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <head>

        <head>
          <script>
           function stopRKey(evt) {
        var evt = (evt) ? evt : ((event) ? event : null);
        var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);
        if ((evt.keyCode == 13) && (node.type == "text")) { return false; }
    }
    document.onkeypress = stopRKey;
          function question1(){
          var checkbox1 = document.getElementById("question1check");
          var question1 = document.getElementById("question1");
          if (question1){
       if (question1.value == "remote access trojan"){
          checkbox1.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
          question1button.innerHTML="";
          question1.readOnly = true;
            }
          else{
            checkbox1.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
          }}};
          function question2(){
          var checkbox2 = document.getElementById("question2check");
          var question2 = document.getElementById("question2");
          if (question2){
       if (question2.value == "gh0st rat"){
          checkbox2.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
          question2.readOnly = true;
          question2button.innerHTML="";
            }
          else{
            checkbox2.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
          }}};
          function question3(){
          var checkbox3 = document.getElementById("question3check");
          var question3 = document.getElementById("question3");
          if (question3){
       if (question3.value == "command and control"){
          checkbox3.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
          question3.readOnly = true;
          question3button.innerHTML="";
            }
          else{
            checkbox3.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
          }}};
          function question4(){
          var checkbox4 = document.getElementById("question4check");
          var question4 = document.getElementById("question4");
          if (question4){
       if (question4.value == "spear phishing"){
          checkbox4.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
          question4.readOnly = true;
          question4button.innerHTML="";
            }
          else{
            checkbox4.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
          }}};
          function question5(){
          var checkbox5 = document.getElementById("question5check");
          var question5 = document.getElementById("question5");
          if (question5){
       if (question5.value == "11882"){
          checkbox5.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
          question5.readOnly = true;
          question5button.innerHTML="";
            }
          else{
            checkbox5.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
          }}};
          function question6(){
          var checkbox6 = document.getElementById("question6check");
          var question6 = document.getElementById("question6");
          if (question6){
          if (question6.value == "fancy bear"){
          checkbox6.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
          question6.readOnly = true;
          question6button.innerHTML="";
            }
          else{
            checkbox6.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
          }}};
          function question7(){
          var checkbox7 = document.getElementById("question7check");
          var question7 = document.getElementById("question7");
          if (question7){
          if (question7.value == "iran"){
          checkbox7.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
          question7.readOnly = true;
          question7button.innerHTML="";
            }
          else{
            checkbox7.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
          }}};
          </script>
            <!-- Required meta tags -->
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">

            <!-- Bootstrap CSS -->
            <link rel='stylesheet' href='//cdn.jsdelivr.net/npm/hack-font@3.3.0/build/web/hack.css'>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
            <link rel='stylesheet' type='text/css' href="main.css"/>
            <link rel="shortcut icon" type="image/png" href="favicon.ico"/>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--Assign the page a title, which is given in the views parameters, if one is not passed in then choose default-->
        <title>APTraining - Question 1</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>


<header class="site-header">
    <nav class="navbar navbar-expand-md navbar-dark bg-steel fixed-top">
      <div class="container">
        <a class="navbar-brand mr-4" href="/">APTraining</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggle" aria-controls="navbarToggle" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarToggle">
          <div class="navbar-nav mr-auto">
<a class="nav-item nav-link" href="index.php">Home</a>
<a class="nav-item nav-link" href="learn.php">Learn</a>
<a class="nav-item nav-link" href="presurvey.php">Pre Survey</a>
<a class="nav-item nav-link" href="postsurvey.php">Post Survey</a>
</div>
<!-- Navbar Right Side -->
<div class="navbar-nav">
<a class="nav-item nav-link" href="genkey.php">Generate Key</a>
<a class="nav-item nav-link" href="continue.php">Continue</a>
<?php if (isset($_SESSION['username'])){ echo "<span class='nav-item nav-link'>Logged in as: " .$_SESSION['username'] . " - Points: " .$row2['points']. "</span>";}
else{
  echo "<span class='nav-item nav-link'>Not logged in</span>";}
?>
          </div>
        </div>
      </div>
    </nav>
  </header>
  <main role="main" class="container">
    <div class="row">
      <div class="col-md-8 col-lg-9">
        <h1>Question 1 - Mindset's a threat - Simple 2 points</h1>
        <p>
          <b>If you get stuck on one of the questions, check the learn modules, they contain the methods necessary to get all of the answers.</b>
        </p>
        <p>In order to defend against a threat, you must understand it. This question will cover some of the attack methods, with examples, that APTs use to compromise targets</p>
        <p>
          Relevant Learn modules: <a href="mitre.php">MITRE</a>, <a href="virustotal.php">Virustotal</a>
        </p>
		  <form class="form-horizontal" method="POST" action="sendq1.php">
<fieldset>


<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question1">A common type of malware used by APTs to maintain access to victims machines: r***** a***** t*****</label>
  <div class="col-md-6">
  <input id="question1" name="question1" type="text" placeholder="" class="form-control input-md"><a href="#" id="question1button" onclick="question1()">Check answer</a>
<div id="question1check">

</div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question2">An example of the above malware type, used in the Operation Dust Storm campaign: g*0*t r*t</label>
  <div class="col-md-6">
  <input id="question2" name="question2" type="text" placeholder="" class="form-control input-md"><a href="#" id="question2button" onclick="question2()">Check answer</a>
  <div id="question2check">

  </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question3">The name of the server that the malware connects to to receive instructions, often shortened to C2: c****** a** con****</label>
  <div class="col-md-6">
  <input id="question3" name="question3" type="text" placeholder="" class="form-control input-md"><a href="#" id="question3button" onclick="question3()">Check answer</a>
  <div id="question3check">

  </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question4">A more targeted form of phishing, designed to manipulate specific targets: s**** p*******</label>
  <div class="col-md-6">
  <input id="question4" name="question4" type="text" placeholder="" class="form-control input-md"><a href="#" id="question4button" onclick="question4()">Check answer</a>
  <div id="question4check">

  </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question5">An old vulnerability in Microsoft Office that allowed attackers to run arbitrary code through crafted documents. CVE-2017- :1***2</label>
  <div class="col-md-6">
  <input id="question5" name="question5" type="text" placeholder="" class="form-control input-md" required=""><a href="#" id="question5button" onclick="question5()">Check answer</a>
  <div id="question5check">

  </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question6">This APT, along with another known as "Cozy Bear", is suspected of interfering in the 2016 US Presidential election by stealing research from the DNC: f**** b***</label>
  <div class="col-md-6">
  <input id="question6" name="question6" type="text" placeholder="" class="form-control input-md"><a href="#" id="question6button" onclick="question6()">Check answer</a>
  <div id="question6check">

  </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question7">The APT known as "Charming Kitten" comes from which country?: i***</label>
  <div class="col-md-6">
  <input id="question7" name="question7" type="text" placeholder="" class="form-control input-md"><a href="#" id="question7button" onclick="question7()">Check answer</a>
  <div id="question7check">

  </div>
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" class="btn btn-primary" href="question2.php">Submit responses</button>
  </div>
</div>

</fieldset>
</form>
		</div>
      <div class="col-md-3 col-sm-0">
        <div class="content-section">
          <h3>All Questions</h3>
          <p class='text-muted'>Preview before answering
            <ul class="list-group">
              <?php if (isset($_SESSION['username'])){
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='presurvey.php'>Pre survey - ",$row['presurvey'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question1.php'>Question 1 - ",$row['question1'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question2.php'>Question 2 - ",$row['question2'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question3.php'>Question 3 - ",$row['question3'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question4.php'>Question 4 - ",$row['question4'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question5.php'>Question 5 - ",$row['question5'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question6.php'>Question 6 - ",$row['question6'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question7.php'>Question 7 - ",$row['question7'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='postsurvey.php'>Post Survey - ",$row['postsurvey'],"</a></li>";
            }
            else{
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question1.php'>Question 1 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question2.php'>Question 2 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question3.php'>Question 3 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question4.php'>Question 4 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question5.php'>Question 5 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question6.php'>Question 6 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question7.php'>Question 7 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question8.php'>Question 8 - Incomplete</a></li>";
            }?>
            </ul>
          </p>
        </div>
      </div>
    </div>
  </main>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    </body>
</html>
