<?php
session_start();
$sessusername=$_SESSION['username'];
require_once "../config.php";
//send data to DB tables
$sql = "UPDATE `questions` SET question7 = 'Complete' WHERE username ='$sessusername'";
$update = mysqli_query($connection, $sql);
$sql2 = "UPDATE `users` SET `points`='32' WHERE `username` = '$sessusername'";
$changepoints = mysqli_query($connection, $sql2);
if ($update){
header("location: ../postsurvey.php");
}
?>
