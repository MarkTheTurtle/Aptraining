<?php
session_start();
include '../config.php';
$sessname = $_SESSION['username'];
$consent1 = $_POST['question1'];
$consent2 = $_POST['question2'];
$consent3 = $_POST['question3'];
$consent4 = $_POST['question4'];
$consent5 = $_POST['question5'];

if (isset($_POST['question6']) && is_array($_POST['question6'])){
	foreach($_POST['question6'] as $question6){
	}
	//this changes the array into a comma separated list for the DB
	$priorexplist = implode(', ',$_POST['question6']);
}
//Send data to DB tables
$question8=$_POST['question8'];
$question7=$_POST['question7'];
$question82=$_POST['question82'];
$question9=$_POST['question9'];
$question10=$_POST['question10'];
$question11=$_POST['question11'];
$question12=$_POST['question12'];
$question13=$_POST['question14'];
$sql = "INSERT INTO `presurvey`(`ID`, `username`, `consent1`, `consent2`, `consent3`, `consent4`, `consent5`, `services`, `lackedu`, `leveloffamiliar`, `linuxknow`, `windowsknow`, `manualremmal`, `researcmalknow`, `syslogslin`, `usevt`) VALUES (NULL,'$sessname','$consent1','$consent2','$consent3','$consent4','$consent5','$priorexplist','$question8','$question7','$question82','$question9','$question10','$question11','$question12','$question13')";
$query =mysqli_query($connection, $sql);
if ($query){
  $sql2 = "UPDATE `questions` SET `presurvey` = 'Complete' WHERE `username`= '$sessname'";
  $query2 = mysqli_query($connection, $sql2);
  header("location:../question1.php");
}
else{
  header("location: presurvey.php?error");
}


 ?>
