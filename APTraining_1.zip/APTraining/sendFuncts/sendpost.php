<?php
include "../config.php";
session_start();
//take variables from form
$question1 = $_POST['question1'];
$question2 = $_POST['question2'];
$question3 = $_POST['question3'];
$question4 = $_POST['question4'];
$question5 = $_POST['question5'];
$question6 = $_POST['question6'];
$question7 = $_POST['question7'];
$question8 = $_POST['question8'];
$question9 = $_POST['question9'];
$question10 = $_POST['question10'];
$question11 = $_POST['question11'];
$question12 = $_POST['question12'];
$question13 = $_POST['question13'];
$question14 = $_POST['question14'];
$sessname = $_SESSION['username'];
$sql = "INSERT INTO `postsurvey`(`ID`, `username`, `effective`, `engrealex`, `goodrange`, `difficulty`, `storyeffective`, `recommend`, `visuals`, `functionality`, `confidenceapt`, `confidenceresearch`, `malwaremanual`, `barrierlack`, `gamification`, `rewards`) VALUES (NULL,'$sessname','$question1','$question2','$question3','$question4','$question5','$question6','$question7','$question8','$question9','$question10','$question11','$question12','$question13','$question14')";
$result = mysqli_query($connection, $sql);
//Send data to DB tables
if ($result){
  $sql2 = "UPDATE `questions` SET `postsurvey` = 'Complete' WHERE `username`= '$sessname'";
  $update = mysqli_query($connection, $sql2);
  header("location: ../finished.php");
}
else{
  header("location: postsurvey.php?error");
}
?>
