<?php
session_start();
$sessusername=$_SESSION['username'];
require_once "../config.php";
//Send data to DB tables
$sql = "UPDATE `questions` SET question3 = 'Complete' WHERE username ='$sessusername'";
$update = mysqli_query($connection, $sql);
$sql2 = "UPDATE `users` SET `points`='12' WHERE `username` = '$sessusername'";
$changepoints = mysqli_query($connection, $sql2);
if ($update){
header("location: ../question4.php");
}
?>
