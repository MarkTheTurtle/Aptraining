<?php
session_start();
$sessusername=$_SESSION['username'];
include "../config.php";
//Send data to DB tables
$sql = "UPDATE `questions` SET question1 = 'Complete' WHERE username ='$sessusername'";
$update = mysqli_query($connection, $sql);
$sql2 = "UPDATE `users` SET `points`='7' WHERE `username` = '$sessusername'";
$changepoints = mysqli_query($connection, $sql2);
if ($update){
  echo $sql2;
}
?>
