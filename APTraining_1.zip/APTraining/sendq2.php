<?php
session_start();
$sessusername=$_SESSION['username'];
require_once "../config.php";

$sql = "UPDATE `questions` SET question2 = 'Complete' WHERE username ='$sessusername'";
$update = mysqli_query($connection, $sql);
if ($update){
header("location: question3.php");
}
?>
