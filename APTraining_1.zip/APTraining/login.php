<?php
include 'config.php';
// Check if the form has been submitted
if (isset($_POST['submit'])) {
    // Get the username and passphrase from the form submission
    $username = $_POST['username'];
    $passphrase = $_POST['passphrase'];
    // Query the database to see if the user exists and the passphrase is correct
    $query = "SELECT * FROM `users` WHERE `username`='$username'";
    $result = mysqli_query($connection, $query);
    $row = mysqli_fetch_assoc($result);
    $passfromdb = $row['password'];
    $pointsfromdb = $row['points'];
    // If a row is returned, the user exists and the passphrase is correct
    if (password_verify($passphrase, $passfromdb)) {
        // Start a session and redirect to the home page
        session_start();
        $_SESSION['username'] = $username;
        $_SESSION['points'] = $pointsfromdb;
        header('location: index.php');
    } else {
        // Display an error message if the user does not exist or the passphrase is incorrect
        header("location: continue.php?wrongcredentials=true");
    }
}
?>
