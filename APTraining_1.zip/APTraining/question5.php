<?php
session_start();
require_once "config.php";
if (isset($_SESSION['username'])){
  $sessusername = $_SESSION['username'];
$compltquery = "SELECT * FROM `questions` WHERE `username` = '$sessusername'";
$results = mysqli_query($connection,$compltquery);
$row = mysqli_fetch_assoc($results);
$points = "SELECT `points` FROM `users` WHERE `username` = '$sessusername'";
$getpoints=mysqli_query($connection, $points);
$row2 = mysqli_fetch_assoc($getpoints);}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <head>

        <head>
            <!-- Required meta tags -->
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <script>
            var button1 = document.getElementById("question1button");
            button1.addEventListener("click", function(){
                question1();
            })
            function question1(){
            var checkbox1 = document.getElementById("question1check");
            var question1 = document.getElementById("question1");
            if (question1){
         if (question1.value == "urgency"){
            checkbox1.innerHTML="<p style=color:#32CD32;>Correct, Well Done</p>";
            question1.readOnly = true;
              }
            else{
              checkbox1.innerHTML="<p style=color:#FF0000;>Incorrect, Try Again (or check caps)</p>";
            }}};
            var button2 = document.getElementById("question2button");
            button2.addEventListener("click", function(){
                question2();
            })
            function question2(){
            var checkbox2 = document.getElementById("question2check");
            var question2 = document.getElementById("question2");
            if (question2){
         if (question2.value == "spoofing"){
            checkbox2.innerHTML="<p style=color:#32CD32;>Correct, Well Done</p>";
            question2.readOnly = true;
              }
            else{
              checkbox2.innerHTML="<p style=color:#FF0000;>Incorrect, Try Again (or check caps)</p>";
            }}};
            function question3(){
            var checkbox3 = document.getElementById("question3check");
            var question3 = document.getElementById("question3");
            if (question3){
         if (question3.value == "social-engineer toolkit"){
            checkbox3.innerHTML="<p style=color:#32CD32;>Correct, Well Done</p>";
            question3.readOnly = true;
              }
            else{
              checkbox3.innerHTML="<p style=color:#FF0000;>Incorrect, Try Again (or check caps)</p>";
            }}};
            function question4(){
            var checkbox4 = document.getElementById("question4check");
            var question4 = document.getElementById("question4");
            if (question4){
         if (question4.value == "n"){
            checkbox4.innerHTML="<p style=color:#32CD32;>Correct, Well Done</p>";
            question4.readOnly = true;
              }
            else{
              checkbox4.innerHTML="<p style=color:#FF0000;>Incorrect, Try Again (or check caps)</p>";
            }}};
            </script>
            <!-- Bootstrap CSS -->
            <link rel='stylesheet' href='//cdn.jsdelivr.net/npm/hack-font@3.3.0/build/web/hack.css'>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
            <link rel='stylesheet' type='text/css' href="main.css"/>
            <link rel="shortcut icon" type="image/png" href="favicon.ico"/>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--Assign the page a title, which is given in the views parameters, if one is not passed in then choose default-->
        <title>APTraining - Question 5</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>


<header class="site-header">
    <nav class="navbar navbar-expand-md navbar-dark bg-steel fixed-top">
      <div class="container">
        <a class="navbar-brand mr-4" href="/">APTraining</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggle" aria-controls="navbarToggle" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarToggle">
          <div class="navbar-nav mr-auto">
<a class="nav-item nav-link" href="index.php">Home</a>
<a class="nav-item nav-link" href="learn.php">Learn</a>
<a class="nav-item nav-link" href="presurvey.php">Pre Survey</a>
<a class="nav-item nav-link" href="postsurvey.php">Post Survey</a>
</div>
<!-- Navbar Right Side -->
<div class="navbar-nav">
<a class="nav-item nav-link" href="genkey.php">Generate Key</a>
<a class="nav-item nav-link" href="continue.php">Continue</a>
<?php if (isset($_SESSION['username'])){ echo "<span class='nav-item nav-link'>Logged in as: " .$_SESSION['username'] . " - Points: " .$row2['points']. "</span>";}
else{
  echo "<span class='nav-item nav-link'>Not logged in</span>";}
?>
          </div>
        </div>
      </div>
    </nav>
  </header>
  <main role="main" class="container">
    <div class="row">
      <div class="col-md-8 col-lg-9">
        <h1>Question 5 - Snakecharmer - Simple 2 points</h1>
	<p>Congratulations once again! You've removed another foothold in the network. However, as the saying goes: one step forward,
		two steps back.</p> <p>You now know that the attack you just quashed came from a client on a local IP, an unfortunate soul in HR who thinks phishing involves Trout; a true end-user. You also know the name of the other account that was compromised, an administrator account. Given that the original user was phished, and the SSH access for the server was quickly gained
		afterwards, perhaps it's time to check the (inept) administrator's inbox for something similar...</p>
		  <img src="imgs/spearphishemail.png"><br><br>
      <p>Oh dear, the inept administrator has been phished as well, and it came from your account! The attackers have been running a spearphishing campaign within your organisation for at least a few weeks, which is what lead to the sudden breaches.</p>
      <form class="form-horizontal" method="POST" action="sendFuncts/sendq5.php">
<fieldset>

<!-- Form Name -->
<legend></legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="question1">One of the tactics used in phishing and spearphishing: urg****</label>
  <div class="col-md-6">
  <input id="question1" name="question1" type="text" placeholder="" class="form-control input-md"><a href="#" id="question1button" onClick="question1()">Check answer</a><br>
  <div id="question1check">

  </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="question2">A technique used by attackers to falsify the source of an email: s***f**g</label>
  <div class="col-md-6">
  <input id="question2" name="question2" type="text" placeholder="" class="form-control input-md"><a href="#" id="question2button" onClick="question2()">Check answer</a><br>
<div id="question2check">

</div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="question3">A program used to perform the above type of attack: social-e******r tool***</label>
  <div class="col-md-6">
  <input id="question3" name="question3" type="text" placeholder="" class="form-control input-md" required=""><a href="#" id="question3button" onClick="question3()">Check answer</a><br>
<div id="question3check">

</div>
  </div>
</div>

<!-- Multiple Radios -->
<div class="form-group">
  <label class="col-md-4 control-label" for="question4">If there are no signs of infection on your own machine or email, is it likely that this was actually sent by your account?: y/n</label>
  <div class="col-md-6">
  <input id="question4" name="question4" type="text" placeholder="" class="form-control input-md"><a href="#" id="question4button" onClick="question4()">Check answer</a><br>
  <div id="question4check">

  </div>

  </div>
</div>
<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" class="btn btn-primary">Submit responses</button>
  </div>
</div>
</fieldset>
</form>

      </div>
      <div class="col-md-3 col-sm-0">
        <div class="content-section">
          <h3>All Questions</h3>
          <p class='text-muted'>Preview before answering
            <ul class="list-group">
              <?php if (isset($_SESSION['username'])){
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='presurvey.php'>Pre survey - ",$row['presurvey'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question1.php'>Question 1 - ",$row['question1'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question2.php'>Question 2 - ",$row['question2'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question3.php'>Question 3 - ",$row['question3'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question4.php'>Question 4 - ",$row['question4'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question5.php'>Question 5 - ",$row['question5'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question6.php'>Question 6 - ",$row['question6'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question7.php'>Question 7 - ",$row['question7'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='postsurvey.php'>Post Survey - ",$row['postsurvey'],"</a></li>";
            }
            else{
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question1.php'>Question 1 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question2.php'>Question 2 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question3.php'>Question 3 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question4.php'>Question 4 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question5.php'>Question 5 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question6.php'>Question 6 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question7.php'>Question 7 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question8.php'>Question 8 - Incomplete</a></li>";
            }?>
            </ul>
          </p>
        </div>
    </div>
  </main>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    </body>
</html>
