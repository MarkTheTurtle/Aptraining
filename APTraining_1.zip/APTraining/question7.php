<?php
session_start();
require_once "config.php";
if (isset($_SESSION['username'])){
  $sessusername = $_SESSION['username'];
$compltquery = "SELECT * FROM `questions` WHERE `username` = '$sessusername'";
$results = mysqli_query($connection,$compltquery);
$row = mysqli_fetch_assoc($results);
$points = "SELECT `points` FROM `users` WHERE `username` = '$sessusername'";
$getpoints=mysqli_query($connection, $points);
$row2 = mysqli_fetch_assoc($getpoints);}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <head>
      <script>
      //stop enter button sending form
       function stopRKey(evt) {
    var evt = (evt) ? evt : ((event) ? event : null);
    var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);
    if ((evt.keyCode == 13) && (node.type == "text")) { return false; }
}
document.onkeypress = stopRKey;
function question1(){
var checkbox1 = document.getElementById("question1check");
var question1 = document.getElementById("question1");
if (question1){
if (question1.value == "safe mode"){
checkbox1.innerHTML="<p style=color:#32CD32;>Correct, Well Done</p>";
question1.readOnly = true;
question1button.innerHTML="";
  }
else{
  checkbox1.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
}}};
function question2(){
var checkbox2 = document.getElementById("question2check");
var question2 = document.getElementById("question2");
if (question2){
if (question2.value == "certutil"){
checkbox2.innerHTML="<p style=color:#32CD32;>Correct, Well Done</p>";
question2.readOnly = true;
question2button.innerHTML="";
  }
else{
  checkbox2.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
}}};
function question3(){
var checkbox3 = document.getElementById("question3check");
var question3 = document.getElementById("question3");
if (question3){
if (question3.value == "W32/Scar.HTKH!tr"){
checkbox3.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
question3.readOnly = true;
question3button.innerHTML="";
  }
else{
  checkbox3.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
}}};
function question4(){
var checkbox4 = document.getElementById("question4check");
var question4 = document.getElementById("question4");
if (question4){
if (question4.value == "-u -r"){
checkbox4.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
question4.readOnly = true;
question4button.innerHTML="";
  }
else if (question4.value== "-r -u") {
  checkbox4.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
  question4.readOnly = true;
  question4button.innerHTML="";
}
else{
  checkbox4.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
}}};
function question5(){
var checkbox5 = document.getElementById("question5check");
var question5 = document.getElementById("question5");
if (question5){
if (question5.value == "sudo deluser --remove-home"){
checkbox5.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
question5.readOnly = true;
question5button.innerHTML="";
  }
else{
  checkbox5.innerHTML="<span style=color:#FF0000;>Incorrect, did you forget sudo?</span>";
}}};
function question6(){
var checkbox6 = document.getElementById("question6check");
var question6 = document.getElementById("question6");
if (question6){
if (question6.value == "passwd root"){
checkbox6.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
question6.readOnly = true;
question6button.innerHTML="";
  }
else{
  checkbox6.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
}}};
function question7(){
var checkbox7 = document.getElementById("question7check");
var question7 = document.getElementById("question7");
if (question7){
if (question7.value == "no ineptadmin"){
checkbox7.innerHTML="<p style=color:#32CD32;>Correct, Well Done</span>";
question7.readOnly = true;
question7button.innerHTML="";
  }
else{
  checkbox7.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
}}};
      </script>
        <head>
            <!-- Required meta tags -->
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">

            <!-- Bootstrap CSS -->
            <link rel='stylesheet' href='//cdn.jsdelivr.net/npm/hack-font@3.3.0/build/web/hack.css'>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
            <link rel='stylesheet' type='text/css' href="main.css"/>
            <link rel="shortcut icon" type="image/png" href="favicon.ico"/>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--Assign the page a title, which is given in the views parameters, if one is not passed in then choose default-->
        <title>APTraining - Question 7</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>


<header class="site-header">
    <nav class="navbar navbar-expand-md navbar-dark bg-steel fixed-top">
      <div class="container">
        <a class="navbar-brand mr-4" href="/">APTraining</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggle" aria-controls="navbarToggle" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarToggle">
          <div class="navbar-nav mr-auto">
<a class="nav-item nav-link" href="index.php">Home</a>
<a class="nav-item nav-link" href="learn.php">Learn</a>
<a class="nav-item nav-link" href="presurvey.php">Pre Survey</a>
<a class="nav-item nav-link" href="postsurvey.php">Post Survey</a>
</div>
<!-- Navbar Right Side -->
<div class="navbar-nav">
<a class="nav-item nav-link" href="genkey.php">Generate Key</a>
<a class="nav-item nav-link" href="continue.php">Continue</a>
<?php if (isset($_SESSION['username'])){ echo "<span class='nav-item nav-link'>Logged in as: " .$_SESSION['username'] . " - Points: " .$row2['points']. "</span>";}
else{
  echo "<span class='nav-item nav-link'>Not logged in</span>";}
?>
          </div>
        </div>
      </div>
    </nav>
  </header>
  <main role="main" class="container">
    <div class="row">
      <div class="col-md-8 col-lg-9">
        <h1>Question 7 - Take the power back - Very Hard 8 points</h1>
        <p>Before you can finish your violation of the Computer misuse act, your manager calls you. It's bad. Breaches on multiple clients, now attempting to spread to
        the main file server. They've given up on the subtlety, now it's a smash and grab. Stealth is out the window. Now it's a fight for your employers Intellectual property.
       This will require all of the skills you have learnt along the way and will serve as the final challenge.</p>
       <p>
         Arriving in to work, you sit down at a client to begin investigating, all the while explaining your theory about Inept Admin to your half awake manager.
       </p>
       <p>
         This malware is different, but the process should be the same; remember how you did it last time? You begin by checking the startup applications...
       </p>
       <img src="imgs/flashelperx.png" />
       <p>
         This time the startup file that has been added is called "FlashHelpX.exe", although searching this online yields nothing. You need the hash.
       </p>
       <form class="form-horizontal" method="POST" action="/sendFuncts/sendq7.php">
<fieldset>

<!-- Form Name -->


<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question1">Before you perform analysis you should reboot into: s**e m**e</label>
  <div class="col-md-6">
  <input id="question1" name="question1" type="text" placeholder="" class="form-control input-md" required=""><a href="#" id="question1button" onclick="question1()">Check answer</a>
  <div id="question1check">

  </div>
  </div>
</div>

<img src="/imgs/certutil.png" />
<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question2">What is the name of the utility you would use in Windows 7 to get the hash of a file: cer****l</label>
  <div class="col-md-6">
  <input id="question2" name="question2" type="text" placeholder="" class="form-control input-md" required=""><a href="#" id="question2button" onclick="question2()">Check answer</a>
  <div id="question2check">

  </div>
  </div>
</div>
<img src="imgs/certutiloutput.png" />

<p>
  Thankfully, you are able to copy the hash directly instead of typing it, the (md5) hash is: f6a79b54c6351c32fe35cda9a78b607f
</p>
<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question3">What label does Fortinet give this MD5 malware hash?: W32/S***.H***!tr</label>
  <div class="col-md-6">
  <input id="question3" name="question3" type="text" placeholder="" class="form-control input-md" required=""><a href="#" id="question3button" onclick="question3()">Check answer</a>
  <div id="question3check">

  </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question4">The Inept Admin might have left some malicious cron jobs, what flags would we use in crontab to remove these for his user account: -* -*</label>
  <div class="col-md-6">
  <input id="question4" name="question4" type="text" placeholder="" class="form-control input-md" required=""><a href="#" id="question4button" onclick="question4()">Check answer</a>
  <div id="question4check">

  </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question5">What is the command to remove a user and their home directory on a Ubuntu system: sudo del**** --re****-h***</label>
  <div class="col-md-6">
  <input id="question5" name="question5" type="text" placeholder="" class="form-control input-md" required=""><a href="#" id="question5button" onclick="question5()">Check answer</a>
  <div id="question5check">

  </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question6">What is the command to change the password of the root user?:  sudo pa***d r***</label>
  <div class="col-md-6">
  <input id="question6" name="question6" type="text" placeholder="" class="form-control input-md" required=""><a href="#" id="question6button" onclick="question6()">Check answer</a>
  <div id="question6check">

  </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question7">What is the command to remove their SSH account on the Cisco ASA 5505?: n* ine**a****</label>
  <div class="col-md-6">
  <input id="question7" name="question7" type="text" placeholder="" class="form-control input-md" required=""><a href="#" id="question7button" onclick="question7()">Check answer</a>
  <div id="question7check">

  </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-8 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" class="btn btn-primary" href="question2.php">Submit responses</button><br /><br />
  </div>
</div>

</fieldset>
</form>

      </div>
      <div class="col-md-3 col-sm-0">
        <div class="content-section">
          <h3>All Questions</h3>
          <p class='text-muted'>Preview before answering
            <ul class="list-group">
              <?php if (isset($_SESSION['username'])){
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='presurvey.php'>Pre survey - ",$row['presurvey'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question1.php'>Question 1 - ",$row['question1'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question2.php'>Question 2 - ",$row['question2'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question3.php'>Question 3 - ",$row['question3'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question4.php'>Question 4 - ",$row['question4'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question5.php'>Question 5 - ",$row['question5'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question6.php'>Question 6 - ",$row['question6'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question7.php'>Question 7 - ",$row['question7'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='postsurvey.php'>Post Survey - ",$row['postsurvey'],"</a></li>";
            }
            else{
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question1.php'>Question 1 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question2.php'>Question 2 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question3.php'>Question 3 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question4.php'>Question 4 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question5.php'>Question 5 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question6.php'>Question 6 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question7.php'>Question 7 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question8.php'>Question 8 - Incomplete</a></li>";
            }?>
            </ul>
          </p>
        </div>
      </div>
    </div>
  </main>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    </body>
</html>
