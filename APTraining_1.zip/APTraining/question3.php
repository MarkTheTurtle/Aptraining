<?php
session_start();
require_once "config.php";
if (isset($_SESSION['username'])){
  $sessusername = $_SESSION['username'];
$compltquery = "SELECT * FROM `questions` WHERE `username` = '$sessusername'";
$results = mysqli_query($connection,$compltquery);
$row = mysqli_fetch_assoc($results);
$points = "SELECT `points` FROM `users` WHERE `username` = '$sessusername'";
$getpoints=mysqli_query($connection, $points);
$row2 = mysqli_fetch_assoc($getpoints);}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <head>

        <head>
            <!-- Required meta tags -->
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
        <script> var points = 0;
            var button = document.getElementById("question2");
            button.addEventListener("click", function(){
                question2();
            })
            function question2(){
            var checkbox = document.getElementById("question2check");
            var malchoice = document.getElementById("malwarechoice");
            if (malchoice){
         if (malchoice.value == "cobaltstrike"){
            checkbox.innerHTML="<p style=color:#32CD32;>Correct, Well Done</p>";
            malchoice.readOnly = true;
            question2button.innerHTML="";
              }
            else{
              question2check.innerHTML="<p style=color:#FF0000;>Incorrect, Try Again (or check caps)</p>";
            }}};
            var button1 = document.getElementById("question1button");
            button1.addEventListener("click", function(){
                question1();
            })
            function question1(){
            var checkbox1 = document.getElementById("question1check");
            var question1 = document.getElementById("question1");
            if (question1){
         if (question1.value == "safe mode"){
            checkbox1.innerHTML="<p style=color:#32CD32;>Correct, Well Done</p>";
            question1.readOnly = true;
            question1button.innerHTML="";
              }
            else{
              checkbox1.innerHTML="<p style=color:#FF0000;>Incorrect, Try Again (or check caps)</p>";
            }}};
            var button2 = document.getElementById("question3button");
            button2.addEventListener("click", function(){
                question3();
            })
            function question3(){
            var checkbox3 = document.getElementById("question3check");
            var question3 = document.getElementById("programname");
            if (question3){
         if (question3.value == "wireshark"){
            checkbox3.innerHTML="<p style=color:#32CD32;>Correct, Well Done</p>";
            question3.readOnly = true;
            question3button.innerHTML="";
              }
            else{
              checkbox3.innerHTML="<p style=color:#FF0000;>Incorrect, Try Again (or check caps)</p>";
            }}};
            var button5 = document.getElementById("question5button");
            button5.addEventListener("click", function(){
                question5();
            })
            function question5(){
            var checkbox5 = document.getElementById("question5check");
            var question5 = document.getElementById("malwarefamily");
            if (question3){
         if (question5.value == "havex"){
            checkbox5.innerHTML="<p style=color:#32CD32;>Correct, Well Done</p>";
            question5.readOnly = true;
            question5button.innerHTML="";
              }
            else{
              checkbox5.innerHTML="<p style=color:#FF0000;>Incorrect, Try Again (or check caps)</p>";
            }}};
            var button4 = document.getElementById("question4button");
            button4.addEventListener("click", function(){
                question4();
            })
            function question4(){
            var checkbox4 = document.getElementById("question4check");
            var question4 = document.getElementById("filename");
            if (question4){
         if (question4.value == "egrabitsetup.exe"){
            checkbox4.innerHTML="<p style=color:#32CD32;>Correct, Well Done</p>";
            question4.readOnly = true;
            question4button.innerHTML="";
              }
            else{
              checkbox4.innerHTML="<p style=color:#FF0000;>Incorrect, Try Again (or check caps)</p>";
            }}};
            </script>
            <!-- Bootstrap CSS -->
            <link rel='stylesheet' href='//cdn.jsdelivr.net/npm/hack-font@3.3.0/build/web/hack.css'>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
            <link rel='stylesheet' type='text/css' href="main.css"/>
            <link rel="shortcut icon" type="image/png" href="favicon.ico"/>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--Assign the page a title, which is given in the views parameters, if one is not passed in then choose default-->
        <title>APTraining - Question 3</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>


<header class="site-header">
    <nav class="navbar navbar-expand-md navbar-dark bg-steel fixed-top">
      <div class="container">
        <a class="navbar-brand mr-4" href="/">APTraining</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggle" aria-controls="navbarToggle" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarToggle">
          <div class="navbar-nav mr-auto">
<a class="nav-item nav-link" href="index.php">Home</a>
<a class="nav-item nav-link" href="learn.php">Learn</a>
<a class="nav-item nav-link" href="presurvey.php">Pre Survey</a>
<a class="nav-item nav-link" href="postsurvey.php">Post Survey</a>
</div>
<!-- Navbar Right Side -->
<div class="navbar-nav">
<a class="nav-item nav-link" href="genkey.php">Generate Key</a>
<a class="nav-item nav-link" href="continue.php">Continue</a>
<?php if (isset($_SESSION['username'])){ echo "<span class='nav-item nav-link'>Logged in as: " .$_SESSION['username'] . " - Points: " .$row2['points']. "</span>";}
else{
  echo "<span class='nav-item nav-link'>Not logged in</span>";}
?>
          </div>
        </div>
      </div>
    </nav>
  </header>
  <main role="main" class="container">
    <div class="row">
      <div class="col-md-8 col-lg-9">
        <h1>Question 3 - Calm like a bomb - Hard 6 points</h1>
        <p>This question will test your situational thinking within a scenario where a machine could be breached, but isn't giving clear indications of compromise. It will rely on your knowledge of the Windows operating system, as well as protocol in an event like this</p>
        <p>After finding the information about the IP addresses, you report to your manager and recieve some bad news, further analysis of the traffic reveals that one of the client machines on the network might have been compromised. The traffic
        between the client and the suspected attacker came from a different IP address than the ones you reviewed, having no flags on its reputation, and all communication beyond the threeway handshake was performed through HTTPS. This leaves analysis of the machine as the only choice. Windows Defender and the secondary antivirus used by your organisation currently find no <b>known</b> threats on the machine. Your manager does not want you to wipe the machine until a threat can be identified.</p>
<form class="form-horizontal" method="POST" action="sendFuncts/sendq3.php">
<fieldset>

<!-- Form Name -->
<legend></legend>


<div class="form-group">
  <label class="col-md-4 control-label" for="question1">When you reach the machine, what is the first thing you should do?: Reboot into s*** mo**</label>
  <div class="col-md-6">
  <input id="question1" name="question1" type="text" placeholder="" class="form-control input-md" required="">

  </div>
</div>
    <a href="#" id="question1button" onClick="question1()">Check answer</a>
    <div id="question1check">

    </div>

<!-- Textarea -->
    <p>Upon checking the startup programs on the infected machine, you find that an unusual DLL has been added. The hash for this file is da146e9bc51330117176c85a3dc9cbbcce01a401497eb63f9829b5e37d53b36e</p>
<img src="imgs/tmpprovider038dll.png">
<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="malwarechoice">Some of the antivirus programs that detect this file as malware list it as c*****s*****</label>
  <div class="col-md-8">
  <input id="malwarechoice" name="malwarechoice" type="text" placeholder="" class="form-control input-md" required=""><a href="#" id="question2" onClick="question2()">Check answer</a>
  <div id="question2check"><br />

  </div>
  </div>
</div>
<img src="imgs/swissitaly.png"><br><br>
<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="programname">What is the name of the program used to capture the traffic in the image?: wi**sha**</label>
  <div class="col-md-8">
  <input id="programname" name="programname" type="text" placeholder="" class="form-control input-md"><a href="#" id="question3button" onClick="question3()">Check answer</a>
  <div id="question3check">

  </div>

  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="filename">Now that we know one of the domains the file contacts, we should be able to find the original file that infected the system before it hid its tracks. The original file was called eg**b**s****.exe </label>
  <div class="col-md-8">
  <input id="filename" name="filename" type="text" placeholder="" class="form-control input-md"><a href="#" id="question4button" onClick="question4()">Check answer</a>
  <div id="question4check">

  </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="malwarefamily">What family does this malware belong to?: h***x</label>
  <div class="col-md-8">
  <input type="text" id="malwarefamily" name="malwarefamily" placeholder="" class="form-control input-md"><a href="#" id="question5button" onClick="question5()">Check answer</a>
<div id="question5check">

</div>
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-8 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" class="btn btn-primary">Submit responses</button><br><br>
  </div>
</div>

</fieldset>
</form>

</div>



      <div class="col-md-3 col-sm-0">
        <div class="content-section">
          <h3>Links</h3>
          <p class='text-muted'>Relevant to the page you're on
            <ul class="list-group">
              <?php if (isset($_SESSION['username'])){
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='presurvey.php'>Pre survey - ",$row['presurvey'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question1.php'>Question 1 - ",$row['question1'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question2.php'>Question 2 - ",$row['question2'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question3.php'>Question 3 - ",$row['question3'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question4.php'>Question 4 - ",$row['question4'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question5.php'>Question 5 - ",$row['question5'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question6.php'>Question 6 - ",$row['question6'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question7.php'>Question 7 - ",$row['question7'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='postsurvey.php'>Post Survey - ",$row['postsurvey'],"</a></li>";
            }
            else{
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question1.php'>Question 1 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question2.php'>Question 2 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question3.php'>Question 3 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question4.php'>Question 4 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question5.php'>Question 5 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question6.php'>Question 6 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question7.php'>Question 7 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question8.php'>Question 8 - Incomplete</a></li>";
            }?>
            </ul>
          </p>
        </div>
      </div>
    </div>
  </main>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    </body>
</html>
