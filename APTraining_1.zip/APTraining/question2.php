<?php
session_start();
require_once "config.php";
if (isset($_SESSION['username'])){
  $sessusername = $_SESSION['username'];
$compltquery = "SELECT * FROM `questions` WHERE `username` = '$sessusername'";
$results = mysqli_query($connection,$compltquery);
$row = mysqli_fetch_assoc($results);
$points = "SELECT `points` FROM `users` WHERE `username` = '$sessusername'";
$getpoints=mysqli_query($connection, $points);
$row2 = mysqli_fetch_assoc($getpoints);}
?>

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <head>

        <head>
          <script>
function question1(){
var checkbox1 = document.getElementById("question1check");
var question1 = document.getElementById("question1");
if (question1){
if (question1.value == "cyprus"){
checkbox1.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
question1.readOnly = true;
question1button.innerHTML="";
  }
else{
  checkbox1.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
}}};
function question2(){
var checkbox2 = document.getElementById("question2check");
var question2 = document.getElementById("question2");
if (question2){
if (question2.value == "turkey"){
checkbox2.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
question2.readOnly = true;
question2button.innerHTML="";
  }
else{
  checkbox2.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
}}};
function question3(){
var checkbox3 = document.getElementById("question3check");
var question3 = document.getElementById("question3");
if (question3){
if (question3.value == "france"){
checkbox3.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
question3.readOnly = true;
question3button.innerHTML="";
  }
else{
  checkbox3.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
}}};
function question4(){
var checkbox4 = document.getElementById("question4check");
var question4 = document.getElementById("question4");
if (question4){
if (question4.value == "1326889953.EXE"){
checkbox4.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
question4.readOnly = true;
question4button.innerHTML="";
  }
else{
  checkbox4.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
}}};
function question5(){
var checkbox5 = document.getElementById("question5check");
var question5 = document.getElementById("question5");
if (question5){
if (question5.value == "energetic bear"){
checkbox5.innerHTML="<span style=color:#32CD32;>Correct, Well Done</span>";
question5.readOnly = true;
question5button.innerHTML="";
  }
else{
  checkbox5.innerHTML="<span style=color:#FF0000;>Incorrect, Try Again (or check caps)</span>";
}}};
          </script>
            <!-- Required meta tags -->
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">

            <!-- Bootstrap CSS -->
            <link rel='stylesheet' href='//cdn.jsdelivr.net/npm/hack-font@3.3.0/build/web/hack.css'>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
            <link rel='stylesheet' type='text/css' href="main.css"/>
            <link rel="shortcut icon" type="image/png" href="favicon.ico"/>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--Assign the page a title, which is given in the views parameters, if one is not passed in then choose default-->
        <title>APTraining - Question 2</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>


<header class="site-header">
    <nav class="navbar navbar-expand-md navbar-dark bg-steel fixed-top">
      <div class="container">
        <a class="navbar-brand mr-4" href="/">APTraining</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggle" aria-controls="navbarToggle" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarToggle">
          <div class="navbar-nav mr-auto">
<a class="nav-item nav-link" href="index.php">Home</a>
<a class="nav-item nav-link" href="learn.php">Learn</a>
<a class="nav-item nav-link" href="presurvey.php">Pre Survey</a>
<a class="nav-item nav-link" href="postsurvey.php">Post Survey</a>
</div>
<!-- Navbar Right Side -->
<div class="navbar-nav">
<a class="nav-item nav-link" href="genkey.php">Generate Key</a>
<a class="nav-item nav-link" href="continue.php">Continue</a>
<?php if (isset($_SESSION['username'])){ echo "<span class='nav-item nav-link'>Logged in as: " .$_SESSION['username'] . " - Points: " .$row2['points']. "</span>";}
else{
  echo "<span class='nav-item nav-link'>Not logged in</span>";}
?>
          </div>
        </div>
      </div>
    </nav>
  </header>
  <main role="main" class="container">
    <div class="row">
      <div class="col-md-8 col-lg-9">
        <h1>Question 2 - Know your enemy - Challenging 4 points</h1>
		  <p style="font-size:20px;"><b>This question will rely on external research using the resources outlined in the Virustotal module on LEARN, if you're struggling with a question, the method to get the answer
      is in there.</b></P>
        <p>You have been tasked with investigating some suspicious traffic on the DMZ server which was picked up by firewall rules. The IPs associated with the traffic have been blacklisted and noted down for your investigation</p>
        <p style='white-space: pre; font-size:20px;'><b>193.37.212.43
212.252.30.170
51.159.28.101</b></p>
		<form class="form-horizontal" action="sendFuncts/sendq2.php">
<fieldset>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="question1">Which country is the first IP located in?: c*****</label>
  <div class="col-md-6">
  <input id="question1" name="question1" type="text" placeholder="" class="form-control input-md" required=""><a href="#" id="question1button" onclick="question1()">Check answer</a>
<div id="question1check">

</div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="question2">Which country is the second IP located in?: t*****</label>
  <div class="col-md-6">
  <input id="question2" name="question2" type="text" placeholder="" class="form-control input-md" required=""><a href="#" id="question2button" onclick="question2()">Check answer</a>
  <div id="question2check">

  </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="question3">Which country is the third IP located in?</label>
  <div class="col-md-6">
  <input id="question3" name="question3" type="text" placeholder="" class="form-control input-md" required=""><a href="#" id="question3button" onclick="question3()">Check answer</a>
  <div id="question3check">

  </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question4">The first IP address is included in a known piece of malware - Complete the title of this: 1326******.EXE</label>
  <div class="col-md-6">
  <input id="question4" name="question4" type="text" placeholder="" class="form-control input-md"><a href="#" id="question4button" onclick="question4()">Check answer</a>
  <div id="question4check">

  </div>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-8 control-label" for="question5">All of these IPs were used in a real campaign by an APT called Crouching Yeti- This APT is also known as en******c bear</label>
  <div class="col-md-6">
  <input id="question5" name="question5" type="text" placeholder="" class="form-control input-md" required=""><a href="#" id="question5button" onclick="question5()">Check answer</a>
  <div id="question5check">

  </div>
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" class="btn btn-primary">Submit responses</button>
  </div>
</div>

</fieldset>
</form>

      </div>
      <div class="col-md-3 col-sm-0">
        <div class="content-section">
          <h3>All Questions</h3>
          <p class='text-muted'>Preview before answering
            <ul class="list-group">
              <?php if (isset($_SESSION['username'])){
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='presurvey.php'>Pre survey - ",$row['presurvey'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question1.php'>Question 1 - ",$row['question1'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question2.php'>Question 2 - ",$row['question2'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question3.php'>Question 3 - ",$row['question3'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question4.php'>Question 4 - ",$row['question4'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question5.php'>Question 5 - ",$row['question5'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question6.php'>Question 6 - ",$row['question6'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question7.php'>Question 7 - ",$row['question7'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='postsurvey.php'>Post Survey - ",$row['postsurvey'],"</a></li>";
            }
            else{
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question1.php'>Question 1 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question2.php'>Question 2 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question3.php'>Question 3 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question4.php'>Question 4 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question5.php'>Question 5 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question6.php'>Question 6 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question7.php'>Question 7 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question8.php'>Question 8 - Incomplete</a></li>";
            }?>
            </ul>
          </p>
        </div>
      </div>
    </div>
  </main>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    </body>
</html>
