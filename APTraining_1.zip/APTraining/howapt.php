<?php
session_start();
include "config.php";
if (isset($_SESSION['username'])){
  $sessusername = $_SESSION['username'];
$compltquery = "SELECT * FROM `questions` WHERE `username` = '$sessusername'";
$results = mysqli_query($connection,$compltquery);
$row = mysqli_fetch_assoc($results);
$points = "SELECT `points` FROM `users` WHERE `username` = '$sessusername'";
$getpoints=mysqli_query($connection, $points);
$row2 = mysqli_fetch_assoc($getpoints);}
 ?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <head>

        <head>
            <!-- Required meta tags -->
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">

            <!-- Bootstrap CSS -->
            <link rel='stylesheet' href='//cdn.jsdelivr.net/npm/hack-font@3.3.0/build/web/hack.css'>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
            <link rel='stylesheet' type='text/css' href="main.css"/>
            <link rel="shortcut icon" type="image/png" href="favicon.ico"/>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--Assign the page a title, which is given in the views parameters, if one is not passed in then choose default-->
        <title>APTraining</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>


<header class="site-header">
    <nav class="navbar navbar-expand-md navbar-dark bg-steel fixed-top">
      <div class="container">
        <a class="navbar-brand mr-4" href="/">APTraining</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggle" aria-controls="navbarToggle" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarToggle">
          <div class="navbar-nav mr-auto">
<a class="nav-item nav-link" href="index.php">Home</a>
<a class="nav-item nav-link" href="about.html">About</a>
<a class="nav-item nav-link" href="learn.php">Learn</a>
<a class="nav-item nav-link" href="presurvey.php">Pre Survey</a>
<a class="nav-item nav-link" href="postsurvey.php">Post Survey</a>
</div>
<!-- Navbar Right Side -->
<div class="navbar-nav">
<a class="nav-item nav-link" href="genkey.php">Generate Key</a>
<a class="nav-item nav-link" href="continue.php">Continue</a>
<?php if (isset($_SESSION['username'])){ echo "<span class='nav-item nav-link'>Logged in as: " .$_SESSION['username'] . " - Points: " .$row2['points']. "</span>";}
else{
  echo "<span class='nav-item nav-link'>Not logged in</span>";}
?>
          </div>
        </div>
      </div>
    </nav>
  </header>
  <main role="main" class="container">
    <div class="row">
      <div class="col-md-8 col-lg-9">
        <h1>How do APTs' operate</h1>
<p>
As mentioned previously, APTs aim to remain undetected for the longest amount of time possible. This is to cause the most damage, or exfiltrate the most data they can.
This does not mean they sit dormant however, and there are a few interpretations of the APT attack cycle from different researchers and institutions. One of these
interpretations goes as follows:<br /><br />

  1. Reconnaissance and Weaponisation – The stage of an attack where information is gathered in preparation to find attack vectors.<br /><br />

  2. Delivery – This is where the leads found in the previous stage are followed up on, often using methods like spear phishing or supply chain attacks.<br /><br />

  3. Initial intrusion – This is the first access to an unauthorised system on the target network/system. Once access to a system has been gained, it is orders of magnitude easier to exploit others.<br /><br />

  4. Command and control – Creating a system to call back to a C2 server, allowing for persistence and further leveraging the foothold to compromise more machines.<br /><br />

  5. Lateral movement – Spreading throughout the network, gaining access to other systems and potentially escalating privileges to gain access to more sensitive information.<br /><br />

  6. Data exfiltration – Since the primary goal of most APTs is to steal sensitive information, this phase will often last as long as they remain undetected.
  Various techniques will be used to obfuscate this process, including compression of data and encrypting communications using TLS/SSL.[1]
</p>
<p>
  While not every attack is going to follow this framework, Stuxnet for example limited data exfiltration instead focusing on causing damage, for the most part they will all
  follow the same rough steps.
</p>
<h1>Attack methods</h1>
<p>
  APTs are infamous for their malware. Some of the most advanced pieces of malware in history have come from APTs. The three most dangerous, and arguably well known pieces of malware have come from APTs.
  These are <b>Stuxnet - The Equation group</b>, <b>Wannacry - The Lazarus group</b> and <b>NotPetya - Sandworm</b>. While Wannacry was financially motivated, Stuxnet and NotPetya were designed purely to cause
  damage to opposing nation states. NotPetya even made itself appear as though it were ransomware (while it was obliterating your file system). Both Wannacry and NotPetya made use of some of the same exploits,
  EternalBlue was present in both and EternalRocks was in NotPetya, making them spread rapidly. While they were used publicly in these malware, they were discovered by the Equation group.
</p>
<p>
  The point of this is that APTs are some of the leaders in Zero day vulnerabilities, exploits which have not been publicly uncovered and thus have has zero days put into patching them. This makes them difficult
  to detect them, and extremely difficult to prevent execution in the right circumstances. As seen in the above example, many of these groups have and use the same exploits as well. There are many reasons for this,
  they all have funds to purchase them if a third party is selling them, they are affiliated with the entities likely to be targeted with them, meaning they can discover and repurpose them, and they have the
  research teams to find them (in some cases colluding with software companies[2]).
</p>
<a href="https://link.springer.com/chapter/10.1007/978-3-662-44885-4_5#citeas">[1] Source for APT attack timeline</a><br />
<a href="https://www.theguardian.com/world/2013/jul/11/microsoft-nsa-collaboration-user-data">[2] NSA working with Microsoft to circumvent encryption</a>
      </div>
      <div class="col-md-3 col-sm-0">
        <div class="content-section">
          <h3>All Questions</h3>
          <p class='text-muted'>Preview before answering
            <ul class="list-group">
              <?php if (isset($_SESSION['username'])){
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='presurvey.php'>Pre survey - ",$row['presurvey'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question1.php'>Question 1 - ",$row['question1'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question2.php'>Question 2 - ",$row['question2'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question3.php'>Question 3 - ",$row['question3'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question4.php'>Question 4 - ",$row['question4'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question5.php'>Question 5 - ",$row['question5'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question6.php'>Question 6 - ",$row['question6'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question7.php'>Question 7 - ",$row['question7'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='postsurvey.php'>Post Survey - ",$row['postsurvey'],"</a></li>";
            }
            else{
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question1.php'>Question 1 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question2.php'>Question 2 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question3.php'>Question 3 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question4.php'>Question 4 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question5.php'>Question 5 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question6.php'>Question 6 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question7.php'>Question 7 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question8.php'>Question 8 - Incomplete</a></li>";
            }?>
            </ul>
          </p>
        </div>
      </div>
    </div>
  </main>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    </body>
</html>
