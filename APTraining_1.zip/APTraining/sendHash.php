<?php
include 'config.php';
//take data from forms
$username=$_POST['username'];
$unhashed = $_POST['passphrase'];
//check length of password, if password is too short then redirect
if (strlen($unhashed) < 12){
	header("Location: genkey.php?success=tooshort");}
$hashed = password_hash($unhashed, PASSWORD_DEFAULT);
//Send data to DB tables
$sql = mysqli_query($connection,"INSERT INTO `users`(`ID`, `username`, `password`, `points`) VALUES (NULL,'$username','$hashed','0')");
	if ($sql){
		$createquestprof = mysqli_query($connection, "INSERT INTO `questions`(`ID`, `username`, `presurvey`, `question1`, `question2`, `question3`, `question4`, `question5`, `question6`, `question7`, `question8`, `postsurvey`) VALUES (NULL,'$username', 'Incomplete','Incomplete','Incomplete','Incomplete','Incomplete','Incomplete','Incomplete','Incomplete','Incomplete','Incomplete')");
		header("Location: continue.php");
}
else{
	header("Location: genkey.php?error=failedquery");
	}
   mysqli_close($connection);
?>
