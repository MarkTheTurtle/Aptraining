<?php
session_start();
include "config.php";
if (isset($_SESSION['username'])){
  $sessusername = $_SESSION['username'];
$compltquery = "SELECT * FROM `questions` WHERE `username` = '$sessusername'";
$results = mysqli_query($connection,$compltquery);
$row = mysqli_fetch_assoc($results);
$points = "SELECT `points` FROM `users` WHERE `username` = '$sessusername'";
$getpoints=mysqli_query($connection, $points);
$row2 = mysqli_fetch_assoc($getpoints);}
 ?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <head>

        <head>
            <!-- Required meta tags -->
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">

            <!-- Bootstrap CSS -->
            <link rel='stylesheet' href='//cdn.jsdelivr.net/npm/hack-font@3.3.0/build/web/hack.css'>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
            <link rel='stylesheet' type='text/css' href="main.css"/>
            <link rel="shortcut icon" type="image/png" href="favicon.ico"/>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--Assign the page a title, which is given in the views parameters, if one is not passed in then choose default-->
        <title>APTraining</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>


<header class="site-header">
    <nav class="navbar navbar-expand-md navbar-dark bg-steel fixed-top">
      <div class="container">
        <a class="navbar-brand mr-4" href="/">APTraining</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggle" aria-controls="navbarToggle" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarToggle">
          <div class="navbar-nav mr-auto">
<a class="nav-item nav-link" href="index.php">Home</a>
<a class="nav-item nav-link" href="learn.php">Learn</a>
<a class="nav-item nav-link" href="presurvey.php">Pre Survey</a>
<a class="nav-item nav-link" href="postsurvey.php">Post Survey</a>
</div>
<!-- Navbar Right Side -->
<div class="navbar-nav">
<a class="nav-item nav-link" href="genkey.php">Generate Key</a>
<a class="nav-item nav-link" href="continue.php">Continue</a>
<?php if (isset($_SESSION['username'])){ echo "<span class='nav-item nav-link'>Logged in as: " .$_SESSION['username'] . " - Points: " .$row2['points']. "</span>";}
else{
  echo "<span class='nav-item nav-link'>Not logged in</span>";}
?>
          </div>
        </div>
      </div>
    </nav>
  </header>
  <main role="main" class="container">
    <div class="row">
      <div class="col-md-8 col-lg-9">
        <h1>How to use APTraining</h1>
<p style="font-size: 25px"><b>This is a short guide on using the application. While it is streamlined, it helps to read this to understand the goals and your participation in it.</b></p>
<p style="font-size: 25px"><b>Before you begin, if you reach a question and decide you cannot complete the rest of the application for whatever reason, please partake in the post survey. The pre and post Survey
 are the most important parts of this application so it would be greatly appreciated if you do them at a minimum.</b>
  </p>
<p style="font-size: 20px">1. To use the app, you <b>will</b> need to generate an account. This will allow you to return at any time with your answers being saved, and you choose the name, allowing for anonimity.
   You do not need to finish the application in one session.<br></p>
<p style="font-size: 20px">2. After generating the account, login in the 'Continue' section and go to the pre-survey page of the application. This is a short survey to gather some of your experiences with other similar programs,
   familiarity with APTs and get your consent to process responses. (This should take around 5 minutes)</p>
<p style="font-size: 20px">3. Go to the learn section of the application, and read through some of the materials. These will contain the information needed to answer the questions in the test section,
  inform you all about how APTs are unique from normal threat actors. This section will take as long as you want it to until you feel ready to begin, though it's reccomended to only view sections you are unfamiliar with.</p>
<p style="font-size: 20px">4. When you feel that you have read enough of the training material, click on question 1 on the side menu, answer the question and you will be automatically guided through the rest of the application.
 The time taken to complete the application will depend wholly on your experience prior to the application. <b>You could breeze through in 10 minutes if you're an expert ot take upto 60 minutes if you struggle.</b></p>
<p style="font-size: 20px">5. When finished, take the post-survey. This will cover your experience with the application, and will offer you the chance to give feedback. (This will take around 5-10 minutes depending on the length of your answers)<p>
<h1>If you cannot finish the application</h1>
<p>
<b>Even if you cannot finish the application, whether it took too much time, was too difficult or you simply did not like it enough to finish, please go to the post survey. Even a negative response is better than no response, as the goal
here is to improve Cybersecurity education. That is the most important section (combined with the presurvey)</b>
</p>
      </div>
      <div class="col-md-3 col-sm-0">
        <div class="content-section">
          <h3>All Questions</h3>
          <p class='text-muted'>Preview before answering
            <ul class="list-group">
              <?php if (isset($_SESSION['username'])){
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='presurvey.php'>Pre survey - ",$row['presurvey'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question1.php'>Question 1 - ",$row['question1'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question2.php'>Question 2 - ",$row['question2'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question3.php'>Question 3 - ",$row['question3'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question4.php'>Question 4 - ",$row['question4'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question5.php'>Question 5 - ",$row['question5'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question6.php'>Question 6 - ",$row['question6'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question7.php'>Question 7 - ",$row['question7'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='postsurvey.php'>Post Survey - ",$row['postsurvey'],"</a></li>";
            }
            else{
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question1.php'>Question 1 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question2.php'>Question 2 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question3.php'>Question 3 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question4.php'>Question 4 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question5.php'>Question 5 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question6.php'>Question 6 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question7.php'>Question 7 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question8.php'>Question 8 - Incomplete</a></li>";
            }?>
            </ul>
          </p>
        </div>
      </div>
    </div>
  </main>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    </body>
</html>
