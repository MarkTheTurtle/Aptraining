<?php
//fill with details of your own webserver
$servername=
$username=
$password=
$dbname=
$connection=new mysqli($servername,$username,$password,$dbname);
	
?>
