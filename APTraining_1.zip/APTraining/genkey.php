<?php
session_start();
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <head>

        <head>
            <!-- Required meta tags -->
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
        
            <!-- Bootstrap CSS -->
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
            <link rel='stylesheet' type='text/css' href="main.css"/>
            <link rel="shortcut icon" type="image/png" href="favicon.ico"/>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--Assign the page a title, which is given in the views parameters, if one is not passed in then choose default-->
        <title>APTraining</title>  
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>


<header class="site-header">
    <nav class="navbar navbar-expand-md navbar-dark bg-steel fixed-top">
      <div class="container">
        <a class="navbar-brand mr-4" href="/">APTraining</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggle" aria-controls="navbarToggle" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarToggle">
          <div class="navbar-nav mr-auto">
<a class="nav-item nav-link" href="index.php">Home</a>
<a class="nav-item nav-link" href="about.html">About</a>
<a class="nav-item nav-link" href="learn.php">Learn</a>
<a class="nav-item nav-link" href="presurvey.php">Pre Survey</a>
<a class="nav-item nav-link" href="postsurvey.php">Post Survey</a>
</div>
<!-- Navbar Right Side -->
<div class="navbar-nav">
<a class="nav-item nav-link" href="genkey.php">Generate Key</a>
<a class="nav-item nav-link" href="continue.php">Continue</a>
          </div>
        </div>
      </div>
    </nav>
  </header>
  <main role="main" class="container">
    <div class="row">
      <div class="col-md-8 col-lg-9">
        <h1>Generate Key</h1>
        <p>This page allows you to generate a cryptographic key, which in turn allows you to save your answers. This has been done so that you do not have to create an identifier or give an email address, since all
    hashes are unique enough to prevent clashes.</p>
        <form class="form-horizontal" method="POST" action="sendHash.php">
<fieldset>

<!-- Form Name -->
<legend></legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="username">User ID</label>  
  <div class="col-md-6">
  <input id="username" name="username" type="text" placeholder="" class="form-control input-md" required="">
    
  </div>
</div>

<!-- Password input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="passphrase">Passphrase</label>
  <div class="col-md-6">
    <input id="passphrase" name="passphrase" type="password" placeholder="" class="form-control input-md" required="" minlength="12">
    
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" class="btn btn-primary">Create account</button>
  </div>
</div>

</fieldset>
</form>
		  <?php	if(isset($_GET["success"])){ //PHP error handling by checking for conditions in the URL
		if($_GET["success"]=="true"){
			echo "<p>Key created successfully</p>";}
		if($_GET["tooshort"]=="true"){
		echo "<p>Passphrase too short</p>";}}
		 if(isset($_GET["error"])){ //PHP error handling by checking for conditions in the URL
		if($_GET["success"]=="failedquery"){
			echo "<p>Key creation failed, please try again</p>";}}
			?>
      </div>
      <div class="col-md-3 col-sm-0">
        <div class="content-section">
          <h3>Links</h3>
          <p class='text-muted'>Relevant to the page you're on
            <ul class="list-group">
              <li style="background:#3F3F3F;" class="list-group-item list-group-item-light"><a class="question-link" href="question1.php">Question 1</a></li>
              <li style="background:#3F3F3F;" class="list-group-item list-group-item-light"><a class="question-link" href="question2.php">Question 2</a></li>
              <li style="background:#3F3F3F;" class="list-group-item list-group-item-light"><a class="question-link" href="question3.php">Question 3</a></li>
              <li style="background:#3F3F3F;" class="list-group-item list-group-item-light"><a class="question-link" href="question4.php">Question 4</a></li>
              <li style="background:#3F3F3F;" class="list-group-item list-group-item-light"><a class="question-link" href="question5.php">Question 5</a></li>
              <li style="background:#3F3F3F;" class="list-group-item list-group-item-light"><a class="question-link" href="question6.php">Question 6</a></li>
              <li style="background:#3F3F3F;" class="list-group-item list-group-item-light"><a class="question-link" href="question7.php">Question 7</a></li>
              <li style="background:#3F3F3F;" class="list-group-item list-group-item-light"><a class="question-link" href="question8.php">Question 8</a></li>
            </ul>
          </p>
        </div>
      </div>
    </div>
  </main>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    </body>
</html> 