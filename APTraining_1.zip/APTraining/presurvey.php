<?php
session_start();
require_once "config.php";
if (isset($_SESSION['username'])){
  $sessusername = $_SESSION['username'];
$compltquery = "SELECT * FROM `questions` WHERE `username` = '$sessusername'";
$results = mysqli_query($connection,$compltquery);
$row = mysqli_fetch_assoc($results);
$points = "SELECT `points` FROM `users` WHERE `username` = '$sessusername'";
$getpoints=mysqli_query($connection, $points);
$row2 = mysqli_fetch_assoc($getpoints);}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <head>

        <head>
            <!-- Required meta tags -->
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">

            <!-- Bootstrap CSS -->
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
            <link rel='stylesheet' type='text/css' href="main.css"/>
            <link rel="shortcut icon" type="image/png" href="favicon.ico"/>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--Assign the page a title, which is given in the views parameters, if one is not passed in then choose default-->
        <title>APTraining - Pre survey</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>


<header class="site-header">
    <nav class="navbar navbar-expand-md navbar-dark bg-steel fixed-top">
      <div class="container">
        <a class="navbar-brand mr-4" href="/">APTraining</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggle" aria-controls="navbarToggle" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarToggle">
          <div class="navbar-nav mr-auto">
            <a class="nav-item nav-link" href="home.html">Home</a>
            <a class="nav-item nav-link" href="learn.html">Learn</a>
            <a class="nav-item nav-link" href="presurvey.html">Pre Survey</a>
            <a class="nav-item nav-link" href="postsurvey.html">Post Survey</a>
          </div>
          <!-- Navbar Right Side -->
          <div class="navbar-nav">
            <a class="nav-item nav-link" href="">Generate Key</a>
            <a class="nav-item nav-link" href="#">Continue</a>
            <?php if (isset($_SESSION['username'])){ echo "<span class='nav-item nav-link'>Logged in as: " .$_SESSION['username'] . " - Points: " .$row2['points']. "</span>";}
            else{
              echo "<span class='nav-item nav-link'>Not logged in</span>";}
            ?>
          </div>
        </div>
      </div>
    </nav>
  </header>
  <main role="main" class="container">
    <div class="row">
      <div class="col-md-8 col-lg-9">
    <h1>Pre-survey and ethics approval</h1>
    <p>This survey will gather your previous expriences with Cybersecurity education as well as your consent to have answers processed.</p>
    <p>
      Under the University guidelines this survey requires ethical approval. All individuals are to remain anonymised as well as
      their responces and individual answers. All information gained in this survey is purely for educational purposes.
      You are free to withdraw from this survey at anytime without reason. If you have any questions, please reach out to
      s4002736@glos.ac.uk.
    </p>
<form class="form-horizontal" method="POST" action="sendFuncts/sendpre.php">
<fieldset>
  <div class="form-group">
    <label class="col-md-8 control-label" for="question1">I confirm that I have read and understand the information provided by the approval statement for the study and have had the opportunity to ask questions that have been answered fully</label>
    <div class="col-md-4">
    <div class="radio">
      <label for="question1-0">
        <input type="radio" name="question1" id="question1-0" value="yes" checked="checked">
        Yes
      </label>
  	</div>
    <div class="radio">
      <label for="question1-1">
        <input type="radio" name="question1" id="question1-1" value="no">
        No
      </label>
  	</div>
    </div>
  </div>
<br />

  <!-- Multiple Radios -->
  <div class="form-group">
    <label class="col-md-8 control-label" for="question2">I have read and received enough information about this study.</label>
    <div class="col-md-4">
    <div class="radio">
      <label for="question2-0">
        <input type="radio" name="question2" id="question2-0" value="yes" checked="checked">
        Yes
      </label>
  	</div>
    <div class="radio">
      <label for="question2-1">
        <input type="radio" name="question2" id="question2-1" value="no">
        No
      </label>
  	</div>
    </div>
  </div>
<br />

  <!-- Multiple Radios -->
  <div class="form-group">
    <label class="col-md-8 control-label" for="question3">I understand that my participation is voluntary, and I am free to withdraw at any time without giving reason.</label>
    <div class="col-md-4">
    <div class="radio">
      <label for="question3-0">
        <input type="radio" name="question3" id="question3-0" value="yes" checked="checked">
        Yes
      </label>
  	</div>
    <div class="radio">
      <label for="question3-1">
        <input type="radio" name="question3" id="question3-1" value="no">
        No
      </label>
  	</div>
    </div>
  </div>
<br />

  <!-- Multiple Radios -->
  <div class="form-group">
    <label class="col-md-8 control-label" for="question4">I agree to take part in this study.</label>
    <div class="col-md-4">
    <div class="radio">
      <label for="question4-0">
        <input type="radio" name="question4" id="question4-0" value="yes" checked="checked">
        Yes
      </label>
  	</div>
    <div class="radio">
      <label for="question4-1">
        <input type="radio" name="question4" id="question4-1" value="no">
        No
      </label>
  	</div>
    </div>
  </div>
<br />

<!-- Multiple Radios -->
<div class="form-group">
  <label class="col-md-8 control-label" for="question5">I agree to have my responses processed for the purposes of evaluating the application and framework</label>
  <div class="col-md-4">
  <div class="radio">
    <label for="radios-0">
      <input type="radio" name="question5" id="radios-0" value="agree" checked="checked">
      I agree
    </label>
  </div>
  <div class="radio">
    <label for="radios-1">
      <input type="radio" name="question5" id="radios-1" value="disagree">
      I disagree
    </label>
  </div>
  </div>
</div>
<br />

<!-- Multiple Checkboxes -->
<div class="form-group">
  <label class="col-md-8 control-label" for="question6">Do you have experience with these Cyber security platforms</label>
  <div class="col-md-4">
  <div class="checkbox">
    <label for="question6-0">
      <input type="checkbox" name="question6[]" id="question6-0" value="tryhackme">
      TryHackMe
    </label>
	</div>
  <div class="checkbox">
    <label for="question6-1">
      <input type="checkbox" name="question6[]" id="question6-1" value="hackthebox">
      HackTheBox
    </label>
	</div>
  <div class="checkbox">
    <label for="question6-2">
      <input type="checkbox" name="question6[]" id="question6-2" value="immersivelabs">
      ImmersiveLabs
    </label>
	</div>
  </div>
</div>
<br />
<!-- Multiple Radios -->
<div class="form-group">
  <label class="col-md-8 control-label" for="question8">Do you feel that there is a lack of education around APTs?</label>
  <div class="col-md-4">
  <div class="radio">
    <label for="question8-0">
      <input type="radio" name="question8" id="question8-0" value="yes" checked="checked">
      Yes
    </label>
	</div>
  <div class="radio">
    <label for="question8-1">
      <input type="radio" name="question8" id="question8-1" value="no">
      No
    </label>
	</div>
  </div>
</div>
<br />

<!-- Multiple Radios (inline) -->
<div class="form-group">
  <label class="col-md-8 control-label" for="question7">How would you rate your knowledge of APTs, 5 being a lot and 1 being very little</label>
  <div class="col-md-4">
    <label class="radio-inline" for="question7-0">
      <input type="radio" name="question7" id="question7-0" value="1" checked="checked">
      1
    </label>
    <label class="radio-inline" for="question7-1">
      <input type="radio" name="question7" id="question7-1" value="2">
      2
    </label>
    <label class="radio-inline" for="question7-2">
      <input type="radio" name="question7" id="question7-2" value="3">
      3
    </label>
    <label class="radio-inline" for="question7-3">
      <input type="radio" name="question7" id="question7-3" value="4">
      4
    </label>
    <label class="radio-inline" for="question7-4">
      <input type="radio" name="question7" id="question7-4" value="5">
      5
    </label>
  </div>
</div>
<br />

<!-- Multiple Radios (inline) -->
<div class="form-group">
  <label class="col-md-8 control-label" for="question8">How well do you know Linux based operating systems, 5 being very much and 1 being not at all</label>
  <div class="col-md-4">
    <label class="radio-inline" for="question8-0">
      <input type="radio" name="question82" id="question8-0" value="1" checked="checked">
      1
    </label>
    <label class="radio-inline" for="question8-1">
      <input type="radio" name="question82" id="question8-1" value="2">
      2
    </label>
    <label class="radio-inline" for="question8-2">
      <input type="radio" name="question82" id="question8-2" value="3">
      3
    </label>
    <label class="radio-inline" for="question8-3">
      <input type="radio" name="question82" id="question8-3" value="4">
      4
    </label>
    <label class="radio-inline" for="question8-4">
      <input type="radio" name="question82" id="question8-4" value="5">
      5
    </label>
  </div>
</div>
<br />

<!-- Multiple Radios (inline) -->
<div class="form-group">
  <label class="col-md-8 control-label" for="question9">How well do you know the Windows operating system, 5 being very much and 1 being not at all</label>
  <div class="col-md-4">
    <label class="radio-inline" for="question9-0">
      <input type="radio" name="question9" id="question9-0" value="1" checked="checked">
      1
    </label>
    <label class="radio-inline" for="question9-1">
      <input type="radio" name="question9" id="question9-1" value="2">
      2
    </label>
    <label class="radio-inline" for="question9-2">
      <input type="radio" name="question9" id="question9-2" value="3">
      3
    </label>
    <label class="radio-inline" for="question9-3">
      <input type="radio" name="question9" id="question9-3" value="4">
      4
    </label>
    <label class="radio-inline" for="question9-4">
      <input type="radio" name="question9" id="question9-4" value="5">
      5
    </label>
  </div>
</div>
<br />

<!-- Multiple Radios (inline) -->
<div class="form-group">
  <label class="col-md-8 control-label" for="question10">How confident would you feel manually detecting and removing malware from a Windows/Linux system, 5 being very and 1 being not at all</label>
  <div class="col-md-4">
    <label class="radio-inline" for="question10-0">
      <input type="radio" name="question10" id="question10-0" value="1" checked="checked">
      1
    </label>
    <label class="radio-inline" for="question10-1">
      <input type="radio" name="question10" id="question10-1" value="2">
      2
    </label>
    <label class="radio-inline" for="question10-2">
      <input type="radio" name="question10" id="question10-2" value="3">
      3
    </label>
    <label class="radio-inline" for="question10-3">
      <input type="radio" name="question10" id="question10-3" value="4">
      4
    </label>
    <label class="radio-inline" for="question10-4">
      <input type="radio" name="question10" id="question10-4" value="5">
      5
    </label>
  </div>
</div>
<br />

<!-- Multiple Radios (inline) -->
<div class="form-group">
  <label class="col-md-8 control-label" for="question11">How confident do you feel in researching unknown files and links, 5 being very and 1 being not at all</label>
  <div class="col-md-4">
    <label class="radio-inline" for="question11-0">
      <input type="radio" name="question11" id="question11-0" value="1" checked="checked">
      1
    </label>
    <label class="radio-inline" for="question11-1">
      <input type="radio" name="question11" id="question11-1" value="2">
      2
    </label>
    <label class="radio-inline" for="question11-2">
      <input type="radio" name="question11" id="question11-2" value="3">
      3
    </label>
    <label class="radio-inline" for="question11-3">
      <input type="radio" name="question11" id="question11-3" value="4">
      4
    </label>
    <label class="radio-inline" for="question11-4">
      <input type="radio" name="question11" id="question11-4" value="5">
      5
    </label>
  </div>
</div>
<br />

<!-- Multiple Radios (inline) -->
<div class="form-group">
  <label class="col-md-8 control-label" for="question12">How confident do you feel in reviewing system logs from Linux systems, 5 being very and 1 being not at all</label>
  <div class="col-md-4">
    <label class="radio-inline" for="question12-0">
      <input type="radio" name="question12" id="question12-0" value="1" checked="checked">
      1
    </label>
    <label class="radio-inline" for="question12-1">
      <input type="radio" name="question12" id="question12-1" value="2">
      2
    </label>
    <label class="radio-inline" for="question12-2">
      <input type="radio" name="question12" id="question12-2" value="3">
      3
    </label>
    <label class="radio-inline" for="question12-3">
      <input type="radio" name="question12" id="question12-3" value="4">
      4
    </label>
    <label class="radio-inline" for="question12-4">
      <input type="radio" name="question12" id="question12-4" value="5">
      5
    </label>
  </div>
</div>
<br />

<!-- Multiple Radios -->
<div class="form-group">
  <label class="col-md-8 control-label" for="question14">Have you ever used Virustotal?</label>
  <div class="col-md-4">
  <div class="radio">
    <label for="question14-0">
      <input type="radio" name="question14" id="question14-0" value="yes" checked="checked">
      Yes
    </label>
	</div>
  <div class="radio">
    <label for="question14-1">
      <input type="radio" name="question14" id="question14-1" value="no">
      No
    </label>
	</div>
  </div>
</div>
<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" class="btn btn-primary">Submit responses</button>
  </div>
</div>
<br />
</fieldset>
</form>

      </div>
      <div class="col-md-3 col-sm-0">
        <div class="content-section">
          <h3>Links</h3>
          <p class='text-muted'>Relevant to the page you're on
            <ul class="list-group">
              <?php if (isset($_SESSION['username'])){
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='presurvey.php'>Pre survey - ",$row['presurvey'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question1.php'>Question 1 - ",$row['question1'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question2.php'>Question 2 - ",$row['question2'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question3.php'>Question 3 - ",$row['question3'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question4.php'>Question 4 - ",$row['question4'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question5.php'>Question 5 - ",$row['question5'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question6.php'>Question 6 - ",$row['question6'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='question7.php'>Question 7 - ",$row['question7'],"</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a class='question-link' href='postsurvey.php'>Post Survey - ",$row['postsurvey'],"</a></li>";
            }
            else{
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question1.php'>Question 1 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question2.php'>Question 2 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question3.php'>Question 3 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question4.php'>Question 4 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question5.php'>Question 5 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question6.php'>Question 6 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question7.php'>Question 7 - Incomplete</a></li>";
              echo "<li style='background:#3F3F3F;' class='list-group-item list-group-item-light'><a style='color:#adafab' href='question8.php'>Question 8 - Incomplete</a></li>";
            }?>
            </ul>
          </p>
        </div>
      </div>
    </div>
  </main>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    </body>
</html>
